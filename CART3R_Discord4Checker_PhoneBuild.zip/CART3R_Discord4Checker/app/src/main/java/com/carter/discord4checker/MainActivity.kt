package com.carter.discord4checker

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 7, 9)
    private val panel = Color.rgb(20, 13, 15)
    private val red = Color.rgb(239, 50, 60)
    private val muted = Color.rgb(177, 164, 168)
    private lateinit var usernameInput: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }
        scroll.addView(content)
        setContentView(scroll)

        content.addView(label("CART3R.JAILBREAK", 25f, Color.WHITE, true))
        content.addView(label("DISCORD 4-CHARACTER CHECKER", 12f, red, true).also {
            it.setPadding(0, dp(5), 0, dp(22))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = rounded(panel, red, 1, 16)
        }
        content.addView(card, matchWrap())

        card.addView(label("SINGLE USERNAME CHECK", 16f, Color.WHITE, true))
        card.addView(label(
            "Enter exactly four letters or numbers. Uppercase letters are converted to lowercase.",
            13f, muted, false
        ).apply { setPadding(0, dp(8), 0, dp(16)) })

        usernameInput = EditText(this).apply {
            hint = "e.g. a1b2"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 18f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(4), InputFilter.AllCaps())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(35, 26, 29), Color.rgb(100, 48, 58), 1, 10)
        }
        card.addView(usernameInput, matchWrap())

        val check = actionButton("CHECK FORMAT", true)
        card.addView(check, matchWrap().apply { topMargin = dp(14) })
        check.setOnClickListener { checkUsername() }

        result = label(
            "STATUS: NOT CHECKED\n\nThis app does not claim a username is available. Discord does not provide a supported public, unauthenticated availability-check endpoint.",
            14f, muted, false
        ).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(28, 23, 25), Color.rgb(88, 58, 65), 1, 10)
        }
        card.addView(result, matchWrap().apply { topMargin = dp(14) })

        val copy = actionButton("COPY USERNAME", false)
        card.addView(copy, matchWrap().apply { topMargin = dp(10) })
        copy.setOnClickListener {
            val value = usernameInput.text.toString().trim().lowercase()
            if (value.length == 4 && value.matches(Regex("[a-z0-9]{4}"))) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Discord username", value))
                toast("Copied: $value")
            } else {
                toast("Enter a valid four-character username first.")
            }
        }

        val open = actionButton("OPEN DISCORD", false)
        card.addView(open, matchWrap().apply { topMargin = dp(10) })
        open.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.com/app"))
            startActivity(intent)
        }

        content.addView(label("HOW TO VERIFY FOR REAL", 16f, Color.WHITE, true).apply {
            setPadding(0, dp(24), 0, dp(8))
        })
        content.addView(label(
            "1. Validate the format here.\n" +
            "2. Tap OPEN DISCORD and sign in through the official app or website.\n" +
            "3. In Discord, open User Settings → My Account / Profiles and use Discord's own username-change flow to see whether the name can be selected.\n" +
            "4. Do not confirm a username change unless you actually want to change your account name.\n\n" +
            "The app never asks for your Discord password, token, or account cookie.",
            13f, muted, false
        ))
        content.addView(label(
            "FORMAT RULE USED\nFour lowercase ASCII letters and/or digits: a–z, 0–9. This checks syntax only, not availability, ownership, or eligibility.",
            13f, muted, false
        ).apply {
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, Color.rgb(75, 38, 46), 1, 12)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        })
        content.addView(label("CART3R Discord4Checker • v1.0.0", 11f, Color.GRAY, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
    }

    private fun checkUsername() {
        val raw = usernameInput.text.toString().trim()
        val value = raw.lowercase()
        if (value.length != 4 || !value.matches(Regex("[a-z0-9]{4}"))) {
            result.text = "STATUS: INVALID FORMAT\n\nUse exactly four characters: a–z and 0–9 only. No spaces, punctuation, or symbols."
            result.setTextColor(Color.rgb(255, 145, 145))
            return
        }
        usernameInput.setText(value)
        result.text = "STATUS: FORMAT VALID • AVAILABILITY UNKNOWN\n\n“$value” matches the four-character format used by this checker.\n\nAvailability cannot be confirmed here. Use Discord's official username-change flow to verify it. No automated request was sent."
        result.setTextColor(Color.rgb(255, 205, 145))
    }

    private fun actionButton(text: String, primary: Boolean): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(
                if (primary) Color.rgb(145, 18, 39) else Color.rgb(48, 29, 34),
                if (primary) red else Color.rgb(111, 54, 66),
                1, 11
            )
            minimumHeight = dp(48)
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun rounded(fill: Int, stroke: Int, strokeWidth: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(fill)
            setCornerRadius(dp(radius).toFloat())
            setStroke(dp(strokeWidth), stroke)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
