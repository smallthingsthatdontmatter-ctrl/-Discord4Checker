# CART3R Discord 4-Checker (Android)

A small native Kotlin Android app for checking whether a candidate matches the requested four-character format (`a-z`, `0-9`), copying it, and opening Discord's official app/site for manual verification.

## Important availability limitation

This app **does not determine whether a username is available**. Discord does not provide a supported public, unauthenticated endpoint for checking arbitrary usernames. The supported account username-change flow is the legitimate place to verify availability while signed in.

The app intentionally does not:
- call undocumented Discord endpoints;
- scrape Discord web pages;
- automate registration or username changes;
- request Discord passwords, tokens, or cookies;
- label an unverified candidate as available or taken.

After pressing **CHECK FORMAT**, a valid candidate is shown as **FORMAT VALID • AVAILABILITY UNKNOWN**.

## Requirements

- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 / Gradle 8.9

## Open and build

1. Extract the ZIP.
2. In Android Studio choose **Open** and select the `CART3R_Discord4Checker` folder.
3. Allow Gradle sync to complete. If prompted, install Android SDK Platform 35.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, normally:
   `app/build/outputs/apk/debug/app-debug.apk`

Or build from a terminal with Gradle 8.9 installed:

```bash
gradle assembleDebug
```

The APK is then at `app/build/outputs/apk/debug/app-debug.apk`.

## App behavior

- Accepts exactly four ASCII letters/digits.
- Converts uppercase input to lowercase.
- Rejects spaces, punctuation, and symbols.
- Copies a valid candidate to the clipboard.
- Opens `https://discord.com/app` for manual verification.
- No network permission is declared; the app does not contact Discord itself.

## Project structure

```text
CART3R_Discord4Checker/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/carter/discord4checker/MainActivity.kt
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Notes

The four-character rule here is a user-requested candidate filter, not a guarantee that Discord will accept every candidate. Discord's policies, account eligibility, and current username rules control the final result.
